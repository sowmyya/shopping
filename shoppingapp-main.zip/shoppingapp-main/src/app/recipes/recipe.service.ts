import { EventEmitter, Injectable, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { Subject } from "rxjs";
import { Ingredient } from "../shared/ingredient.model";
import { ShoppingListService } from "../shopping-list/shopping-list.service";
import { Recipe } from "./recipe.model"
@Injectable()
export class RecipeService
{
  recipeSelected=new EventEmitter<Recipe>();
  recipesChanged=new Subject<Recipe[]>();
  private recipes: Recipe[]= [new Recipe('test recipe 1',
                                         'this is simply a test',
                                         'https://www.simplyrecipes.com/thmb/JWjdE8YwikAae0KZuyy6ZJW7Utw=/3000x2001/filters:no_upscale():max_bytes(150000):strip_icc()/Simply-Recipes-Homemade-Pizza-Dough-Lead-Shot-1c-c2b1885d27d4481c9cfe6f6286a64342.jpg',
                                          [new Ingredient('flour',2),
                                           new Ingredient('sauce',2)]),
  new Recipe('test recipe 2','this is simply a test','https://www.simplyrecipes.com/thmb/JWjdE8YwikAae0KZuyy6ZJW7Utw=/3000x2001/filters:no_upscale():max_bytes(150000):strip_icc()/Simply-Recipes-Homemade-Pizza-Dough-Lead-Shot-1c-c2b1885d27d4481c9cfe6f6286a64342.jpg',
  [new Ingredient('flour',2),
                                           new Ingredient('sauce',2)])];
 constructor(private slService: ShoppingListService)
 {
  
 }

 setRecipes(recipes: Recipe[])
 {
  this.recipes=recipes;
  this.recipesChanged.next(this.recipes.slice());
 }
  getRecipes()
  {
return this.recipes.slice();
  }
  getRecipe(id:number)
  {
return this.recipes[id];
  }

  addIngredientsToShoppingList(ingredients: Ingredient[])
  {
this.slService.addIngredients(ingredients);
  }


  addRecipe(recipe: Recipe)
  {
    this.recipes.push(recipe);
    this.recipesChanged.next(this.recipes.slice());
  }

  updateRecipe(index:number, newRecipe: Recipe)
  {
    this.recipes[index]=newRecipe;
    this.recipesChanged.next(this.recipes.slice());

  }

  deleteRecipe(index:number)
  {
    this.recipes.splice(index,1);
    this.recipesChanged.next(this.recipes.slice());
  }

  

}